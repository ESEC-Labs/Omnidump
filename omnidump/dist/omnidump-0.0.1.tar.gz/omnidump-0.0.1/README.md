# memdump

[![PyPI - Version](https://img.shields.io/pypi/v/memdump.svg)](https://pypi.org/project/memdump)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/memdump.svg)](https://pypi.org/project/memdump)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install memdump
```

## License

`memdump` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

